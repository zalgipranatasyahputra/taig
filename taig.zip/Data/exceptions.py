class SentryBlockException(Exception):
    pass
