![Taig Logo](/Data/TaigLogo.jpg)

## Table of Contents
* [The Feature](#the-features)
* [Installation](#installation)
* [Video Instalation](#video-installation)

## The Features
* Bot Like
  * Like all hastag post
  * Like all user post
  * Like all popular post
* Bot Komen
  * Comment all hastag post
  * Comment all user post
  * Comment all popular post
* Bot Follow
  * Follow user by hashtag
  * Follow back all user
* Bot Unfollow
  * Unfollow not follow back
  * Unfollow all user

## Installation
```
$ pkg install git python
$ git clone https://github.com/zalgipranatasyahputra/taig
$ cd taig
$ pip install -r requirements.txt
$ python taig.py
```